package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import javax.xml.bind.DatatypeConverter;
import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    @RestController
    public class ChecksumController {

        @GetMapping("/hash")
        public Map<String, String> getChecksum() {
            String data = "Nur Faizah Mas Mohd Khalik";
            Map<String, String> response = new HashMap<>();
            response.put("data", data);
            response.put("Name of Cipher Algorithm Used", "SHA-256");
            response.put("SHA Value", generateChecksum(data));
            return response;
        }
    

    public String generateChecksum(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            return DatatypeConverter.printHexBinary(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}}
